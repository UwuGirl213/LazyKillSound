# How to install?
-Copy "LazyKillSound" to mods folder (R2Northstar/mods) and Copy "MOVE TO TITANFALL 2 FOLDER" to ofcourse the titanfall2 folder

# How to add my own killsound?
-Convert your killsound from youtube using a yt to mp4 converter(a wav or mp3 wont work)
download here incase you dont have it yet http://www.radgametools.com/bnkdown.htm

-After successfully turning it into a bik file copy it to media (r2/media)

# Kingpiss, it doesnt work! :(
Ping @KingPiss#2446 if nothing works, dont be shy

# Changelog
1.0.0 - release
1.0.2 - unable to install error fix attempt(fail)
1.0.3 - unable to install error fix attempt(fail)
1.0.4 - unable to install error fix attempt(fail)
1.0.5 - unable to install error fix attempt(success)